#!/usr/bin/env python3
"""Offline frozen-Snowflake project-access report analysis. No network calls.

Project retrieval is NOT a task-access assertion. A balanced partition of a
single snapshot is NOT independent extraction validation. Decimal minutes are
authoritative; hours are displayed without changing the source metric.
"""
import argparse
import csv
import hashlib
import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, getcontext
from pathlib import Path

getcontext().prec = 60
csv.field_size_limit(sys.maxsize)
FOLDERS = ('parent_folder_id', 'child_folder_id', 'grandchild_folder_id',
           'baby_folder_id', 'grandbaby_folder_id')
TASKS = ('parent_task_id', 'child_task_id', 'grandchild_task_id',
         'baby_task_id', 'grandbaby_task_id', 'great_grandbaby_task_id')
METRIC = 'effortallocation_totaleffort'
NULLS = {'', 'null', 'none', 'nan', 'nat', '<na>', '\\n', 'placeholder'}
MISSING = {'NOT_FOUND', 'FORBIDDEN'}


def ident(value):
    value = str(value or '').strip()
    return '' if value.lower() in NULLS else value


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def load(path):
    with Path(path).open(encoding='utf-8-sig') as f:
        return json.load(f)


def rows(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f, strict=True)
        headers = [str(v).strip().lower() for v in (reader.fieldnames or [])]
        if not headers or '' in headers or len(set(headers)) != len(headers):
            raise ValueError('Blank or duplicate CSV headers: ' + str(path))
        reader.fieldnames = headers
        for number, row in enumerate(reader, 2):
            if None in row or any(v is None for v in row.values()):
                raise ValueError(f'Malformed CSV record {number}: {path}')
            yield number, row


def numeric(value):
    value = str(value or '').strip()
    if value.lower() in NULLS:
        return None, 'NULL_EFFORT'
    if len(value) > 100 or not re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?', value):
        return None, 'INVALID_EFFORT'
    try:
        result = Decimal(value)
        if not result.is_finite() or (result and abs(result.adjusted()) > 30):
            return None, 'INVALID_EFFORT'
        if result < 0:
            return None, 'NEGATIVE_EFFORT'
        return result, ''
    except InvalidOperation:
        return None, 'INVALID_EFFORT'


def hours(value):
    return None if value is None else value / Decimal(60)


def expect(condition, message):
    if not condition:
        raise ValueError(message)


def utc_time(value):
    try:
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except (ValueError, AttributeError, TypeError):
        raise ValueError('Invalid capture evidence timestamp')
    expect(result.tzinfo is not None, 'Capture timestamp has no timezone')
    return result.astimezone(timezone.utc)


def select_case(snapshot, case=None):
    digest = sha(snapshot)
    if case is not None:
        candidates = [Path(case).resolve()]
    else:
        candidates = []
        for path in (snapshot.parent / 'output' / 'project_access_today').glob('*/summary.json'):
            record = load(path)
            if (record.get('status') == 'ACCESS_CAPTURE_COMPLETE_REVIEW_REQUIRED'
                    and record.get('snapshot', {}).get('sha256') == digest):
                candidates.append(path.parent.resolve())
    expect(len(candidates) == 1,
           'Expected one completed access capture matching this snapshot; supply --case explicitly')
    return candidates[0], digest


def validate_case(case, snapshot_hash):
    manifest = load(case / 'hashes.json')
    expect(isinstance(manifest, dict) and manifest, 'Invalid capture hash manifest')
    required = {'summary.json', 'snapshot_inventory.json', 'akash_access.json',
                'supplemental_type_evidence.json', 'project_access_review.csv'}
    expect(required <= set(manifest), 'Capture manifest does not cover required evidence files')
    for name, digest in manifest.items():
        path = Path(name)
        expect(not path.is_absolute() and '..' not in path.parts and path.parts,
               'Unsafe relative path in capture manifest')
        target = (case / path).resolve()
        expect(target.is_relative_to(case) and target.is_file(), 'Missing or unsafe evidence path: ' + name)
        expect(re.fullmatch(r'[a-fA-F0-9]{64}', str(digest)) is not None, 'Invalid file hash: ' + name)
        expect(sha(target) == digest.lower(), 'Evidence hash mismatch: ' + name)
    actual_raw = {str(p.relative_to(case)) for p in (case / 'raw').glob('*.json')}
    expect(actual_raw and actual_raw <= set(manifest), 'Raw API files missing or not hash-covered')
    summary = load(case / 'summary.json')
    inventory = load(case / 'snapshot_inventory.json')
    access = load(case / 'akash_access.json')
    supplemental = load(case / 'supplemental_type_evidence.json')
    expect(summary.get('status') == 'ACCESS_CAPTURE_COMPLETE_REVIEW_REQUIRED', 'Capture is incomplete')
    expect(summary['snapshot'] == inventory['audit'], 'Snapshot audit differs between capture files')
    expect(summary['snapshot']['sha256'] == snapshot_hash, 'Snapshot hash does not match access capture')
    entities = inventory['entities']
    projects, folders, checks = (access[k] for k in ('projects', 'folders', 'direct_checks'))
    expect(not set(projects) & set(folders), 'Project/folder inventories overlap')
    expect(set(checks) == set(entities) - (set(projects) | set(folders)), 'Direct-check ID coverage mismatch')
    expect(set(supplemental) <= {k for k, v in checks.items() if v['outcome'] != 'RETRIEVED'},
           'Unexpected supplemental type-check ID')
    expected_counts = {'visible_project_inventory_count': len(projects),
                       'visible_folder_inventory_count': len(folders),
                       'baseline_container_count': len(entities), 'direct_check_count': len(checks)}
    for key, value in expected_counts.items():
        expect(summary.get(key) == value, 'Capture summary count mismatch: ' + key)

    # Verify each inventory page and the direct lookups against saved raw replies.
    raw = [load(case / name) for name in sorted(actual_raw)]
    capture_start, capture_end = utc_time(summary['started_at']), utc_time(summary['finished_at'])
    expect(capture_start <= capture_end, 'Invalid capture time ordering')
    for r in raw:
        started, finished = utc_time(r.get('started_at')), utc_time(r.get('finished_at'))
        expect(capture_start <= started <= finished <= capture_end, 'Raw request outside capture window')
        expect(r.get('role_label') in ('akash', 'surya_type_only'), 'Unexpected token-role label')
        endpoint = r.get('endpoint', '')
        expect(endpoint == 'folders' or re.fullmatch(r'folders/[A-Za-z0-9_-]+', endpoint),
               'Unexpected raw request endpoint')
    successful = [r for r in raw if r.get('http_status') == 200]
    for project_flag, saved in ((True, projects), (False, folders)):
        pages = [r for r in successful if r.get('role_label') == 'akash'
                 and r.get('endpoint') == 'folders'
                 and (r.get('params') or {}).get('project') == ('true' if project_flag else 'false')]
        expect(pages, 'Missing successful raw inventory pages')
        found, cursor, cursors = {}, None, set()
        for index, r in enumerate(pages):
            params = r['params']
            expect(params.get('deleted') == 'false' and params.get('pageSize') == 1000,
                   'Unexpected inventory request parameters')
            expect(params.get('nextPageToken') == cursor, 'Broken inventory pagination chain')
            body = r.get('response') or {}
            expect(body.get('kind') == 'folders' and isinstance(body.get('data'), list), 'Bad raw inventory response')
            for item in body['data']:
                fid = item.get('id')
                expect(isinstance(fid, str) and fid not in found, 'Duplicate or invalid raw inventory ID')
                expect(isinstance(item.get('project'), dict) == project_flag, 'Raw inventory type mismatch')
                found[fid] = {'item': item, 'observed_at': r['finished_at'], 'via': 'inventory'}
            cursor = body.get('nextPageToken') or None
            if cursor:
                expect(isinstance(cursor, str) and cursor not in cursors, 'Repeated pagination cursor')
                cursors.add(cursor)
            else:
                expect(index == len(pages) - 1, 'Inventory has pages after final page')
        expect(cursor is None and found == saved, 'Raw inventory differs from saved inventory')
    for role, saved in (('akash', checks), ('surya_type_only', supplemental)):
        for fid, result in saved.items():
            matching = [r for r in raw if r.get('role_label') == role
                        and r.get('endpoint') == 'folders/' + fid
                        and r.get('finished_at') == result.get('observed_at')]
            expect(len(matching) == 1, 'Missing or ambiguous raw direct lookup: ' + fid)
            r = matching[0]
            expect(r.get('params') is None and r.get('http_status') == result.get('http_status'),
                   'Direct lookup request/result mismatch: ' + fid)
            if result.get('item'):
                body = r.get('response') or {}
                expect(r['http_status'] == 200 and body.get('kind') == 'folders'
                       and body.get('data') == [result['item']] and result['item'].get('id') == fid,
                       'Direct lookup item differs from raw evidence: ' + fid)
                expect(result.get('outcome') == 'RETRIEVED', 'Retrieved lookup outcome mismatch')
            elif result.get('outcome') in MISSING:
                expect(r['http_status'] == (404 if result['outcome'] == 'NOT_FOUND' else 403)
                       and isinstance(r.get('api_error'), str), 'Missing-project outcome mismatch')
            else:
                expect(result.get('outcome') == 'UNRESOLVED', 'Unknown lookup outcome')
    visible = {**projects, **folders}
    review = {}
    for _, row in rows(case / 'project_access_review.csv'):
        fid = row['container_id']
        expect(fid and fid not in review, 'Blank or duplicate review container ID')
        review[fid] = row
    expect(set(review) == set(entities) | set(projects), 'Review CSV ID coverage mismatch')
    for fid, row in review.items():
        sf = entities.get(fid, {})
        a = visible.get(fid) or checks.get(fid, {})
        item = a.get('item') or supplemental.get(fid, {}).get('item') or {}
        aitem = a.get('item', {})
        kind = ('PROJECT' if isinstance(item.get('project'), dict) else 'FOLDER') if item else 'UNVERIFIED'
        scope = aitem.get('scope', '')
        outcome = ('RECYCLE_BIN' if scope == 'RbFolder' else 'RETRIEVED') if aitem else a.get('outcome', 'UNRESOLVED')
        expected = {'name': item.get('title') or ' | '.join(sf.get('names', [])),
                    'current_type': kind, 'in_frozen_snapshot': str(int(fid in entities)),
                    'akash_access': outcome, 'akash_scope': scope,
                    'type_evidence': 'akash' if aitem else ('surya' if item else 'none'),
                    'akash_http_status': str(a.get('http_status', 200 if aitem else '') or ''),
                    'akash_observed_at': a.get('observed_at', ''),
                    'akash_evidence_method': a.get('via', ''),
                    'snapshot_own_project_flags': ' | '.join(sf.get('own_project_flags', []))}
        for key, value in expected.items():
            expect(row.get(key) == value, f'Review CSV differs from evidence for {fid}: {key}')
    expect(dict(Counter(r['current_type'] + ' / ' + r['akash_access'] for r in review.values()))
           == summary['classification_counts'], 'Review CSV classification counts mismatch')
    return summary, inventory, review


def analyze(snapshot_path, case_path=None):
    snapshot = Path(snapshot_path).resolve()
    case, snapshot_hash = select_case(snapshot, case_path)
    capture, inventory, review = validate_case(case, snapshot_hash)
    audit, entities = inventory['audit'], inventory['entities']
    projects = {fid: r for fid, r in review.items() if r['current_type'] == 'PROJECT'}
    accessible = {fid for fid, r in projects.items() if r['akash_access'] == 'RETRIEVED'}
    missing = {fid for fid, r in projects.items() if r['akash_access'] in MISSING}
    task_data, folder_keys, ambiguous_keys = {}, set(), set()
    observed_entities, stamps, refreshes = set(), Counter(), Counter()
    scope_rows, scope_ambiguous, direct_rows = Counter(), Counter(), Counter()
    scope_ambiguous_rows = defaultdict(set)
    row_issues, counters = [], Counter()
    raw_known_minutes = Decimal(0)
    raw_unknown_cells = 0
    row_count = 0
    required = {'id', 'key', 'title', METRIC, 'snapshot_exported_at', *FOLDERS, *TASKS}
    for source_row, row in rows(snapshot):
        if row_count == 0:
            expect(required <= set(row), 'Required snapshot columns missing: ' + ', '.join(sorted(required-set(row))))
            expect(len(row) == len(audit['columns']), 'Snapshot column count mismatch')
        row_count += 1
        stamps[row['snapshot_exported_at'].strip()] += 1
        refreshes[row.get('data refresh', '').strip()] += 1
        key, container = ident(row['key']), ident(row['id'])
        scopes = {ident(row[c]) for c in FOLDERS} | {container}
        scopes.discard('')
        observed_entities.update(scopes)
        scope_rows.update(scopes)
        if container:
            direct_rows[container] += 1
        task_path = [ident(row[c]) for c in TASKS]
        deepest = next((v for v in reversed(task_path) if v), '')
        value, error = numeric(row[METRIC])
        if error:
            raw_unknown_cells += 1
        else:
            raw_known_minutes += value
        folder_identity = bool(key and key in scopes)
        contradictory = bool(folder_identity and key in task_path)
        if folder_identity and not contradictory:
            counters['folder_or_project_own_rows_excluded'] += 1
            folder_keys.add(key)
            continue
        if contradictory or not key or not deepest or key != deepest:
            counters['ambiguous_identity_rows'] += 1
            scope_ambiguous.update(scopes)
            for scope in scopes:
                scope_ambiguous_rows[scope].add(source_row)
            if key:
                ambiguous_keys.add(key)
            row_issues.append({'source_excel_row': source_row, 'task_key': key,
                               'deepest_task_id': deepest, 'issue': 'AMBIGUOUS_IDENTITY',
                               'container_ids': ';'.join(sorted(scopes))})
            continue
        counters['eligible_task_rows'] += 1
        task = task_data.setdefault(key, {'values': set(), 'issues': set(), 'rows': [],
                                        'names': set(), 'scopes': set(), 'project_rows': defaultdict(list),
                                        'direct': set()})
        task['rows'].append(source_row)
        if row.get('title'):
            task['names'].add(row['title'])
        task['scopes'].update(scopes)
        if container:
            task['direct'].add(container)
        for pid in scopes & projects.keys():
            task['project_rows'][pid].append(source_row)
        if error:
            task['issues'].add(error)
        else:
            task['values'].add(value)
    expect(row_count == audit['data_rows'], 'Snapshot row count differs from capture audit')
    expect(dict(stamps) == audit['snapshot_timestamps'], 'Snapshot timestamp counts differ from audit')
    expect(dict(refreshes) == audit['data_refresh_values'], 'Snapshot refresh counts differ from audit')
    expect(observed_entities == set(entities), 'Snapshot container IDs differ from captured inventory')
    for fid in entities:
        expect(scope_rows[fid] == entities[fid]['scope_rows'], 'Snapshot scope count mismatch: ' + fid)
    expect(sha(snapshot) == snapshot_hash, 'Snapshot changed during analysis')
    project_tasks, direct_tasks = defaultdict(set), defaultdict(set)
    partitions = {name: set() for name in ('ACCESSIBLE_ONLY', 'MISSING_ONLY', 'BOTH', 'NEITHER')}
    task_rows, link_rows = [], []
    for tid in sorted(task_data):
        task = task_data[tid]
        if len(task['values']) > 1:
            task['issues'].add('CONFLICTING_EFFORT')
        if tid in ambiguous_keys or tid in folder_keys:
            task['issues'].add('AMBIGUOUS_IDENTITY')
        task['minutes'] = next(iter(task['values'])) if len(task['values']) == 1 and not task['issues'] else None
        pids = set(task['project_rows'])
        a, m = pids & accessible, pids & missing
        group = 'BOTH' if a and m else 'ACCESSIBLE_ONLY' if a else 'MISSING_ONLY' if m else 'NEITHER'
        partitions[group].add(tid)
        for pid in pids:
            project_tasks[pid].add(tid)
            link_rows.append({'project_id': pid, 'task_id': tid,
                              'source_excel_rows': ';'.join(map(str, task['project_rows'][pid])),
                              'effort_minutes': task['minutes'], 'effort_hours': hours(task['minutes'])})
        for pid in task['direct'] & projects.keys():
            direct_tasks[pid].add(tid)
        task_rows.append({'task_id': tid, 'task_name': ' | '.join(sorted(task['names'])),
                          'effort_minutes': task['minutes'], 'effort_hours': hours(task['minutes']),
                          'partition': group, 'accessible_project_count': len(a),
                          'missing_project_count': len(m), 'all_project_count': len(pids),
                          'accessible_project_ids': ';'.join(sorted(a)),
                          'missing_project_ids': ';'.join(sorted(m)),
                          'all_project_ids': ';'.join(sorted(pids)),
                          'physical_row_count': len(task['rows']),
                          'first_source_excel_row': task['rows'][0],
                          'source_excel_rows': ';'.join(map(str, task['rows'])),
                          'status': 'REVIEW_REQUIRED' if task['issues'] else 'CALCULATED',
                          'issues': ';'.join(sorted(task['issues']))})

    def total(keys, identity_count=0):
        keys = set(keys)
        unknown = sum(task_data[k]['minutes'] is None for k in keys)
        known = sum((task_data[k]['minutes'] for k in keys if task_data[k]['minutes'] is not None), Decimal(0))
        value = None if unknown or identity_count else known
        return {'task_count': len(keys), 'effort_minutes': value, 'effort_hours': hours(value),
                'known_subtotal_minutes': known, 'known_subtotal_hours': hours(known),
                'unknown_effort_task_count': unknown, 'ambiguous_identity_row_count': identity_count}

    project_rows, other_rows, type_issues = [], [], []
    for fid, item in sorted(review.items(), key=lambda kv: (kv[1]['name'].casefold(), kv[0])):
        base = dict(item)
        base['in_frozen_snapshot'] = int(base['in_frozen_snapshot'])
        flags = set()
        for v in entities.get(fid, {}).get('own_project_flags', []):
            if v.strip().lower() in ('true', '1', '1.0', 'y', 'yes'):
                flags.add(True)
            elif v.strip().lower() in ('false', '0', '0.0', 'n', 'no'):
                flags.add(False)
        type_conflict = bool(len(flags) > 1 or (flags and item['current_type'] != 'UNVERIFIED'
                                               and (item['current_type'] == 'PROJECT') not in flags))
        base['snapshot_type_conflict'] = int(type_conflict)
        if type_conflict:
            type_issues.append({'container_id': fid, 'issue': 'SNAPSHOT_CURRENT_TYPE_CONFLICT'})
        if fid not in projects:
            other_rows.append(base)
            continue
        base['project_id'], base['project_name'] = fid, base['name']
        base['access_group'] = 'ACCESSIBLE' if fid in accessible else 'MISSING' if fid in missing else 'UNRESOLVED'
        data = total(project_tasks[fid], scope_ambiguous[fid])
        if not base['in_frozen_snapshot']:
            data['effort_minutes'] = data['effort_hours'] = None
            status = 'NOT_IN_SNAPSHOT'
        elif data['effort_minutes'] is None:
            status = 'REVIEW_REQUIRED'
        else:
            status = 'CALCULATED' if data['task_count'] else 'NO_RECORDED_TASKS'
        base.update(data)
        base.update(effort_status=status, scope_physical_row_count=scope_rows[fid],
                    direct_task_count=len(direct_tasks[fid]),
                    shared_task_count=sum(len(task_data[t]['project_rows']) > 1 for t in project_tasks[fid]),
                    metric_note='Frozen Snowflake planned effort; not independently fetched task access')
        project_rows.append(base)
    akeys = partitions['ACCESSIBLE_ONLY'] | partitions['BOTH']
    mkeys = partitions['MISSING_ONLY'] | partitions['BOTH']
    amb_total = counters['ambiguous_identity_rows']
    # Ambiguous rows can hide tasks; conservatively block partition authority.
    a_ambiguous_rows = set().union(*(scope_ambiguous_rows[p] for p in accessible))
    m_ambiguous_rows = set().union(*(scope_ambiguous_rows[p] for p in missing))
    measures = {'SNAPSHOT_UNIQUE_TASKS': total(task_data, amb_total),
                'ACCESSIBLE_PROJECT_UNION': total(akeys, len(a_ambiguous_rows)),
                'MISSING_PROJECT_UNION': total(mkeys, len(m_ambiguous_rows)),
                **{name: total(keys, amb_total) for name, keys in partitions.items()}}
    labels = {'SNAPSHOT_UNIQUE_TASKS': 'All eligible unique tasks in frozen snapshot',
              'ACCESSIBLE_PROJECT_UNION': 'Unique tasks under retrievable projects',
              'MISSING_PROJECT_UNION': 'Unique tasks under unavailable projects',
              'ACCESSIBLE_ONLY': 'Tasks under retrievable projects only',
              'MISSING_ONLY': 'Tasks under unavailable projects only',
              'BOTH': 'Tasks shared by retrievable and unavailable projects',
              'NEITHER': 'Tasks outside both project unions'}
    recon = [{'metric_id': key, 'label': labels[key], **value, 'note': ''} for key, value in measures.items()]
    global_minutes = measures['SNAPSHOT_UNIQUE_TASKS']['effort_minutes']
    terms = [measures[k]['effort_minutes'] for k in ('ACCESSIBLE_PROJECT_UNION', 'MISSING_PROJECT_UNION', 'BOTH', 'NEITHER')]
    residual = None if global_minutes is None or any(v is None for v in terms) else global_minutes-(terms[0]+terms[1]-terms[2]+terms[3])
    expect(residual is None or residual == 0, 'Internal partition arithmetic failed')
    recon.append({'metric_id': 'PARTITION_RESIDUAL', 'label': 'Snapshot minus accessible minus missing plus overlap minus remainder',
                  'task_count': None, 'effort_minutes': residual, 'effort_hours': hours(residual),
                  'known_subtotal_minutes': None, 'known_subtotal_hours': None,
                  'unknown_effort_task_count': None, 'ambiguous_identity_row_count': amb_total,
                  'note': 'An accounting identity from one input; not independent completeness validation'})
    for group, ids, union_key in (('ACCESSIBLE', accessible, 'ACCESSIBLE_PROJECT_UNION'),
                                  ('MISSING', missing, 'MISSING_PROJECT_UNION')):
        included = [r for r in project_rows if r['project_id'] in ids and r['in_frozen_snapshot']]
        value = None if any(r['effort_minutes'] is None for r in included) else sum((r['effort_minutes'] for r in included), Decimal(0))
        union = measures[union_key]['effort_minutes']
        for suffix, amount, label in (('PROJECT_ROW_SUM', value, 'Sum of baseline project rows; shared tasks repeat'),
                                      ('WITHIN_GROUP_OVERLAP', None if value is None or union is None else value-union,
                                       'Excess from tasks counted in multiple project rows in this group')):
            recon.append({'metric_id': group+'_'+suffix, 'label': group.title()+' '+label,
                          'task_count': None, 'effort_minutes': amount, 'effort_hours': hours(amount),
                          'known_subtotal_minutes': None, 'known_subtotal_hours': None,
                          'unknown_effort_task_count': None, 'ambiguous_identity_row_count': None,
                          'note': 'API-only projects excluded because snapshot effort is unknown'})
    notes = ['Effort uses one frozen Snowflake snapshot; access was checked afterward.',
             'Project retrieval does not prove access to every associated task.',
             '403/404 classify current retrieval outcomes, not proven historical permission causes.',
             'API-only project effort is unknown, not zero.',
             'Project scopes use the union of id and five stored folder hierarchy columns.',
             'Snapshot zeros are retained; the source may have replaced missing effort with zero.',
             'Partition equality is not independent validation of extraction completeness.',
             'Source Excel row numbers include the header row and refer to the raw snapshot sheet.']
    metadata = {'created_at': datetime.now(timezone.utc).isoformat(), 'snapshot_path': str(snapshot),
                'snapshot_sha256': snapshot_hash, 'snapshot_bytes': snapshot.stat().st_size,
                'case_path': str(case), 'capture_hash_manifest_sha256': sha(case/'hashes.json'),
                'analysis_script_sha256': sha(Path(__file__)), 'capture_started_at': capture['started_at'],
                'capture_finished_at': capture['finished_at'], 'snapshot_timestamps': dict(stamps),
                'data_refresh_values': dict(refreshes), 'snapshot_columns': audit['columns'],
                'token_identity': capture.get('token_identity', 'Role labels not independently verified'), 'notes': notes}
    summary = {'status': 'OFFLINE_ANALYSIS_COMPLETE_REVIEW_REQUIRED', 'snapshot_data_rows': row_count,
               'snapshot_column_count': len(audit['columns']), 'baseline_container_count': len(entities),
               'review_record_count': len(review), 'classification_counts': capture['classification_counts'],
               'baseline_accessible_project_count': sum(r['in_frozen_snapshot'] for r in project_rows if r['access_group']=='ACCESSIBLE'),
               'baseline_missing_project_count': sum(r['in_frozen_snapshot'] for r in project_rows if r['access_group']=='MISSING'),
               'api_only_project_count': sum(not r['in_frozen_snapshot'] for r in project_rows),
               'unique_task_count': len(task_data), 'project_task_link_count': len(link_rows),
               'mapping_counts': dict(counters), 'task_issue_counts': dict(Counter(v for t in task_data.values() for v in t['issues'])),
               'snapshot_current_type_conflict_count': len(type_issues), 'global_effort_minutes': global_minutes,
               'global_effort_hours': hours(global_minutes), 'partition_residual_minutes': residual,
               'raw_numeric_row_sum_minutes': raw_known_minutes, 'raw_unknown_effort_cells': raw_unknown_cells,
               'raw_sum_note': 'Diagnostic only: includes repeated task rows and non-task rows; not task effort total',
               'independent_extraction_validation': False}
    link_rows.sort(key=lambda row: (row['project_id'], row['task_id']))
    return {'metadata': metadata, 'summary': summary, 'project_rows': project_rows,
            'task_rows': task_rows, 'link_rows': link_rows, 'other_container_rows': other_rows,
            'reconciliation_rows': recon, 'issues': row_issues + type_issues}


def json_default(value):
    if isinstance(value, Decimal):
        return str(value)
    raise TypeError(type(value).__name__)


def write_outputs(report, output_dir):
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    with (output/'analysis_summary.json').open('x', encoding='utf-8') as f:
        json.dump({'metadata': report['metadata'], 'summary': report['summary'],
                   'reconciliation': report['reconciliation_rows']}, f, indent=2, default=json_default)
    for key, filename in (('project_rows', 'project_effort.csv'), ('task_rows', 'task_audit.csv'),
                          ('link_rows', 'project_task_links.csv'), ('other_container_rows', 'other_containers.csv'),
                          ('reconciliation_rows', 'reconciliation.csv'), ('issues', 'review_issues.csv')):
        records = report[key]
        headers = list(dict.fromkeys(k for row in records for k in row)) or ['no_records']
        with (output/filename).open('x', encoding='utf-8-sig', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(records)
    with (output/'output_hashes.json').open('x', encoding='utf-8') as f:
        json.dump({p.name: sha(p) for p in output.iterdir() if p.is_file() and p.name != 'output_hashes.json'}, f, indent=2)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--snapshot', default='snowflake_snapshot.csv')
    parser.add_argument('--case')
    parser.add_argument('--output')
    args = parser.parse_args()
    report = analyze(args.snapshot, args.case)
    output = args.output or str(Path(args.snapshot).resolve().parent/'output'/'holistic_effort'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ'))
    write_outputs(report, output)
    print(json.dumps(report['summary'], indent=2, default=json_default))
    print('OUTPUT:', str(Path(output).resolve()))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, csv.Error) as error:
        raise SystemExit('ANALYSIS STOPPED: ' + str(error))
