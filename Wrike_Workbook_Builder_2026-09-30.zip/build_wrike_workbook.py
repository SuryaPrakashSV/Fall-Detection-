#!/usr/bin/env python3
"""Build the Wrike snapshot reconciliation on the user's Mac, entirely offline.

Uses the locally installed XlsxWriter package in constant-memory mode.
Inputs are read only. Output is a new timestamped directory. No API calls.
"""
import argparse
import csv
import hashlib
import json
import math
import shutil
import sys
import zipfile
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
import wrike_report_analysis as analysis

START = 5  # zero-based first detail row; Excel row 6
MAX_ROWS = 1048576


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()


def cell(col, row):
    letters = ''
    col += 1
    while col:
        col, n = divmod(col - 1, 26)
        letters = chr(65+n) + letters
    return letters + str(row + 1)


class Writer:
    def __init__(self, path):
        import xlsxwriter
        self.book = xlsxwriter.Workbook(str(path), {
            'constant_memory': True, 'strings_to_formulas': False,
            'strings_to_urls': False, 'strings_to_numbers': False,
            'tmpdir': str(Path(path).parent)})
        self.book.set_properties({'title': 'Wrike project access and planned effort',
            'author': 'Surya', 'comments': 'Frozen Snowflake effort classified by observed project access.'})
        self.book.set_calc_mode('auto')
        self.base = self.book.add_format({'font_name': 'Arial', 'font_size': 10, 'valign': 'vcenter'})
        self.title = self.book.add_format({'font_name': 'Arial', 'font_size': 16, 'bold': True, 'font_color': '#17365D'})
        self.note = self.book.add_format({'font_name': 'Arial', 'font_size': 10, 'font_color': '#555555'})
        self.head = self.book.add_format({'font_name': 'Arial', 'font_size': 10, 'bold': True,
            'bg_color': '#24476A', 'font_color': '#FFFFFF', 'text_wrap': True,
            'valign': 'vcenter', 'align': 'center'})
        self.num = self.book.add_format({'font_name': 'Arial', 'font_size': 10, 'num_format': '#,##0.00;[Red](#,##0.00)'})
        self.integer = self.book.add_format({'font_name': 'Arial', 'font_size': 10, 'num_format': '#,##0'})
        self.warn = self.book.add_format({'font_name': 'Arial', 'font_size': 10, 'bg_color': '#FFF2CC', 'font_color': '#7F6000'})
        self.sheets, self.ranges, self.overflow = {}, {}, []

    def new_sheet(self, name):
        s = self.book.add_worksheet(name)
        self.sheets[name] = s
        s.hide_gridlines(2)
        s.set_default_row(15)
        s.set_zoom(90)
        s.set_column(0, 30, 20, self.base)
        return s

    def value(self, sheet, row, col, value, fmt=None):
        if value is None or value == '':
            return
        if isinstance(value, bool):
            result = sheet.write_number(row, col, int(value), fmt or self.integer)
        elif isinstance(value, (int, float, Decimal)):
            if not math.isfinite(float(value)):
                raise ValueError('Nonfinite number in workbook input')
            result = sheet.write_number(row, col, float(value), fmt or (self.integer if isinstance(value,int) else self.num))
        else:
            if isinstance(value, (list, dict, set, tuple)):
                value = json.dumps(list(value) if isinstance(value, set) else value, ensure_ascii=False, default=str)
            text = str(value)
            # Excel's text limit is 32,767 characters. Preserve oversize values in chunks.
            if len(text.encode('utf-16-le')) // 2 > 32767:
                ref = len(self.overflow)+1
                self.overflow.append((ref, sheet.name, row+1, col+1, text))
                text = f'[Full value in Long Cell Values, reference {ref}; {len(text)} characters]'
            result = sheet.write_string(row, col, text, fmt or self.base)
        if result != 0:
            raise ValueError(f'Excel write failed at {sheet.name}!{cell(col,row)}: {result}')

    def formula(self, sheet, row, col, formula, cached, fmt=None):
        result = sheet.write_formula(row, col, formula, fmt or self.num,
                                    '' if cached is None else float(cached) if isinstance(cached,(int,float,Decimal)) else cached)
        if result != 0:
            raise ValueError('Formula write failed')

    def heading(self, sheet, title, note, fields, widths=None):
        self.value(sheet,1,0,title,self.title)
        self.value(sheet,2,0,note,self.note)
        sheet.set_row(1,23)
        sheet.set_row(4,32)
        for col, label in enumerate(fields):
            self.value(sheet,4,col,label,self.head)
            if widths:
                sheet.set_column(col,col,widths[col],self.base)
        sheet.freeze_panes(START, min(2,len(fields)))

    def finish_table(self, sheet, count, columns):
        if count + START > MAX_ROWS:
            raise ValueError(f'{sheet.name} exceeds Excel row limit')
        if count:
            sheet.autofilter(START-1,0,START+count-1,columns-1)
        self.ranges[sheet.name] = {'header_excel_row': START, 'data_rows': count, 'columns':columns}

    def generic(self, name, rows, note, fields=None):
        s=self.sheets.get(name) or self.new_sheet(name)
        keys=fields or list(dict.fromkeys(k for item in rows for k in item)) or ['Result']
        widths=[50 if ('name' in k or 'note' in k or 'reason' in k) else 25 for k in keys]
        self.heading(s,name,note,[k.replace('_',' ').capitalize() for k in keys],widths)
        for r,item in enumerate(rows,START):
            for c,k in enumerate(keys):
                self.value(s,r,c,item.get(k))
        self.finish_table(s,len(rows),len(keys))
        return s

    def raw_snapshot(self, snapshot, expected_rows, expected_sha):
        print('Writing the complete Snowflake snapshot...',flush=True)
        s=self.sheets['Snowflake Snapshot']
        csv.field_size_limit(sys.maxsize)
        n=0
        with Path(snapshot).open(encoding='utf-8-sig',newline='') as f:
            reader=csv.reader(f)
            headers=next(reader)
            s.set_column(0,len(headers)-1,22,self.base)
            s.freeze_panes(1,1)
            s.set_row(0,42)
            for c,h in enumerate(headers):
                self.value(s,0,c,h,self.head)
            numeric={c for c,h in enumerate(headers) if h.strip().lower() in (
                'effortallocation_totaleffort','totaleffortminutes','owner_dailyallocation','owner_effortminutes_per_day')}
            for n,row in enumerate(reader,1):
                if len(row)!=len(headers):
                    raise ValueError('Snapshot changed or malformed while writing')
                if n>=MAX_ROWS:
                    raise ValueError('Snapshot exceeds Excel row limit')
                for c,v in enumerate(row):
                    if not v:
                        continue
                    value=v
                    if c in numeric:
                        try:
                            d=Decimal(v)
                            if d.is_finite() and len(d.normalize().as_tuple().digits)<=15:
                                value=d
                        except InvalidOperation:
                            pass
                    self.value(s,n,c,value)
                if n%25000==0:
                    print(f'Snapshot rows written: {n:,}/{expected_rows:,}',flush=True)
        if n!=expected_rows or file_sha(snapshot)!=expected_sha:
            raise ValueError('Snapshot row count/hash changed; workbook invalid')
        s.autofilter(0,0,n,len(headers)-1)
        self.ranges[s.name]={'header_excel_row':1,'data_rows':n,'columns':len(headers)}

    def write_overflow(self):
        if not self.overflow:
            return
        s=self.new_sheet('Long Cell Values')
        keys=['Reference','Source sheet','Excel row','Excel column','Chunk number','Full value SHA256','Text chunk']
        self.heading(s,'Long cell values','Join chunks in chunk-number order to reconstruct the original text.',keys,[12,25,12,12,12,68,100])
        row=START
        for ref,sheet,sr,sc,text in list(self.overflow):
            digest=hashlib.sha256(text.encode('utf-8')).hexdigest()
            for offset in range(0,len(text),16000):
                if row>=MAX_ROWS:
                    raise ValueError('Long Cell Values exceeds Excel row limit')
                for c,v in enumerate([ref,sheet,sr,sc,offset//16000+1,digest,text[offset:offset+16000]]):
                    self.value(s,row,c,v)
                row+=1
        self.finish_table(s,row-START,len(keys))

    def close(self):
        self.book.close()


def write_report(report, snapshot, path):
    w=Writer(path)
    for name in ['Reconciliation','Accessible Projects','Missing Projects','Other Projects',
                 'Task Effort','Project Task Links','Access Evidence','Other Containers',
                 'Review Issues','Snowflake Snapshot']:
        w.new_sheet(name)
    w.sheets['Reconciliation'].activate()
    w.sheets['Reconciliation'].set_tab_color('#17365D')
    for name in ['Accessible Projects','Missing Projects']:
        w.sheets[name].set_tab_color('#557DA5')
    task_rows=report['task_rows']
    task_excel={r['task_id']:i+START+1 for i,r in enumerate(task_rows)}
    source_headers=report['metadata']['snapshot_columns']
    metric_col=[h.strip().lower() for h in source_headers].index('effortallocation_totaleffort')
    s=w.sheets['Task Effort']
    fields=['Task ID','Task name','Snapshot Excel row','Planned effort minutes','Planned effort hours',
            'Partition','Calculation status','Physical rows','Accessible project IDs','Missing project IDs',
            'All project IDs','All source Excel rows','Issues']
    w.heading(s,'Task effort','One consistent value per own task ID. Hours = minutes / 60.',fields,
              [25,60,18,22,22,23,22,15,40,40,40,30,45])
    for n,t in enumerate(task_rows,START):
        first=t.get('first_source_excel_row') or int(t['source_excel_rows'].split(';')[0])
        values=[t['task_id'],t['task_name'],first,None,None,t['partition'],t['status'],t['physical_row_count'],
                t['accessible_project_ids'],t['missing_project_ids'],t['all_project_ids'],t['source_excel_rows'],t['issues']]
        for col,val in enumerate(values):
            w.value(s,n,col,val)
        if t['effort_minutes'] is not None:
            rawref="'Snowflake Snapshot'!"+cell(metric_col,first-1)
            w.formula(s,n,3,'='+rawref+'*1',t['effort_minutes'])
            w.formula(s,n,4,'='+cell(3,n)+'/60',t['effort_hours'])
        if (n-START+1)%50000==0:
            print('Task effort rows written:',n-START+1,flush=True)
    w.finish_table(s,len(task_rows),len(fields))
    # Group membership links by project. Project totals reference contiguous ranges.
    links=sorted(report['link_rows'],key=lambda x:(x['project_id'],x['task_id']))
    link_ranges={}
    s=w.sheets['Project Task Links']
    fields=['Project ID','Task ID','Planned effort minutes','Planned effort hours','Task Effort Excel row','Source Excel rows']
    w.heading(s,'Project task links','One project/task pair per row. A task can appear under several projects.',fields,[25,25,23,23,24,40])
    for n,t in enumerate(links,START):
        pid=t['project_id']; tr=task_excel[t['task_id']]
        link_ranges.setdefault(pid,[n+1,n+1])[1]=n+1
        for col,val in enumerate([pid,t['task_id'],None,None,tr,t['source_excel_rows']]):
            w.value(s,n,col,val)
        if t['effort_minutes'] is not None:
            w.formula(s,n,2,f"='Task Effort'!D{tr}",t['effort_minutes'])
            w.formula(s,n,3,f"='Task Effort'!E{tr}",t['effort_hours'])
    w.finish_table(s,len(links),len(fields))
    project_ranges={}
    for sheetname,group in [('Accessible Projects','ACCESSIBLE'),('Missing Projects','MISSING'),('Other Projects','UNRESOLVED')]:
        rows=[r for r in report['project_rows'] if r['access_group']==group]
        s=w.sheets[sheetname]
        fields=['Project ID','Project name','In snapshot','Unique tasks','Planned effort hours','Effort status',
                'Akash retrieval','HTTP status','Access observed UTC','Unknown effort tasks','Ambiguous rows',
                'Shared tasks','Project Task Links rows','Planned effort minutes','Snapshot/type conflict']
        w.heading(s,sheetname,'Effort comes from frozen Snowflake. Project row sums include shared tasks.',fields,
                  [25,65,14,15,23,25,19,12,30,20,18,16,26,23,22])
        for n,p in enumerate(rows,START):
            span=link_ranges.get(p['project_id'])
            spantext=f'{span[0]}:{span[1]}' if span else ''
            vals=[p['project_id'],p['project_name'],p['in_frozen_snapshot'],p['task_count'],None,p['effort_status'],
                  p['akash_access'],p.get('akash_http_status'),p.get('akash_observed_at'),p['unknown_effort_task_count'],
                  p['ambiguous_identity_row_count'],p['shared_task_count'],spantext,None,p['snapshot_type_conflict']]
            for col,val in enumerate(vals):
                w.value(s,n,col,val)
            if p['effort_minutes'] is not None:
                w.formula(s,n,13,(f"=SUM('Project Task Links'!C{span[0]}:C{span[1]})" if span else '=0'),p['effort_minutes'])
                w.formula(s,n,4,'='+cell(13,n)+'/60',p['effort_hours'])
        w.finish_table(s,len(rows),len(fields))
        project_ranges[group]=(sheetname,len(rows))
    # Summary cells expose the partition arithmetic and link to task-level formulas.
    s=w.sheets['Reconciliation']
    w.heading(s,'Wrike project access and planned effort','All effort uses one frozen Snowflake snapshot; access checks occurred afterward.',
              ['Measure','Unique tasks','Planned effort hours','Unknown effort tasks','Ambiguous rows'],[72,18,24,22,20])
    metrics={r['metric_id']:r for r in report['reconciliation_rows']}
    metric_positions={r['metric_id']:START+i+1 for i,r in enumerate(report['reconciliation_rows'])}
    task_end=START+len(task_rows)
    hourrange=f"'Task Effort'!$E$6:$E${max(6,task_end)}"
    grouprange=f"'Task Effort'!$F$6:$F${max(6,task_end)}"
    for n,m in enumerate(report['reconciliation_rows'],START):
        k=m['metric_id']; value=m['effort_hours']; formula=None
        if k=='SNAPSHOT_UNIQUE_TASKS':
            formula='=SUM('+hourrange+')'
        elif k in ('ACCESSIBLE_ONLY','MISSING_ONLY','BOTH','NEITHER'):
            formula=f'=SUMIFS({hourrange},{grouprange},"{k}")'
        elif k in ('ACCESSIBLE_PROJECT_UNION','MISSING_PROJECT_UNION'):
            part='ACCESSIBLE_ONLY' if k.startswith('ACCESSIBLE') else 'MISSING_ONLY'
            formula=f'=SUMIFS({hourrange},{grouprange},"{part}")+SUMIFS({hourrange},{grouprange},"BOTH")'
        elif k=='PARTITION_RESIDUAL':
            pos=metric_positions
            formula=f'=C{pos["SNAPSHOT_UNIQUE_TASKS"]}-C{pos["ACCESSIBLE_PROJECT_UNION"]}-C{pos["MISSING_PROJECT_UNION"]}+C{pos["BOTH"]}-C{pos["NEITHER"]}'
        elif k.endswith('_PROJECT_ROW_SUM'):
            group=k.removesuffix('_PROJECT_ROW_SUM'); sheetname,count=project_ranges[group]
            formula=f"=SUM('{sheetname}'!E6:E{max(6,START+count)})"
        elif k.endswith('_WITHIN_GROUP_OVERLAP'):
            group=k.removesuffix('_WITHIN_GROUP_OVERLAP')
            formula=f'=C{metric_positions[group+"_PROJECT_ROW_SUM"]}-C{metric_positions[group+"_PROJECT_UNION"]}'
        vals=[m['label'],m.get('task_count'),None,m.get('unknown_effort_task_count'),m.get('ambiguous_identity_row_count')]
        for c,v in enumerate(vals):w.value(s,n,c,v)
        if value is None:
            w.value(s,n,2,'UNAVAILABLE',w.warn)
        elif formula:
            w.formula(s,n,2,formula,value)
        else:w.value(s,n,2,value)
    row=START+len(metrics)+2
    meta=report['metadata']; summary=report['summary']
    info=[('Snapshot exported (recorded value)', '; '.join(meta['snapshot_timestamps'])),
          ('Source Data refresh (recorded value)', '; '.join(meta['data_refresh_values'])),
          ('Access capture began (UTC)',meta['capture_started_at']),('Access capture ended (UTC)',meta['capture_finished_at']),
          ('Raw snapshot data rows',summary['snapshot_data_rows']),('Raw snapshot columns',summary['snapshot_column_count']),
          ('Accessible baseline projects',summary['baseline_accessible_project_count']),
          ('Missing baseline projects',summary['baseline_missing_project_count']),
          ('API-only projects; snapshot effort unavailable',summary['api_only_project_count']),
          ('Raw effort-column sum, minutes (repeated rows included)',summary['raw_numeric_row_sum_minutes']),
          ('Raw cells with unknown effort',summary['raw_unknown_effort_cells']),
          ('Task identity issues',summary['mapping_counts'].get('ambiguous_identity_rows',0)),
          ('Snapshot/current project-type conflicts',summary['snapshot_current_type_conflict_count']),
          ('Snapshot SHA256',meta['snapshot_sha256']),
          ('Identity of tokens',meta['token_identity']),
          ('Interpretation','Effort associated with currently retrievable/unavailable projects in the frozen snapshot.'),
          ('Limit','Project retrieval does not establish that Akash can retrieve every associated task.'),
          ('Reconciliation limit','A zero partition residual checks accounting, not independent extraction completeness.'),
          ('Scope','All statuses. Task/subtask own records. Project scope uses id plus five folder hierarchy IDs.'),
          ('Source preservation','All raw rows/columns retained. Oversized cell text, if any, is preserved in Long Cell Values.'),
          ('Workbook use','Fixed evidence report. Rebuild from source to change scope, identities or access classifications.')]
    for label,value in info:
        w.value(s,row,0,label)
        w.value(s,row,1,value)
        row+=1
    s.set_landscape();s.fit_to_pages(1,0);s.set_print_scale(75)
    s.set_column(1,1,30,w.base)
    s.set_column(2,2,24,w.base)
    # Display long source notes in a wide ordinary text region, without shrinking fonts.
    for label,value in [('Definitions','Accessible/missing labels describe observed project retrieval, not independently fetched task effort.')]:
        w.value(s,row+1,0,label);w.value(s,row+1,1,value)
    s.conditional_format(START,2,START+len(metrics)-1,2,{'type':'text','criteria':'containing','value':'UNAVAILABLE','format':w.warn})
    w.ranges[s.name]={'metric_rows':len(metrics),'metadata_rows':len(info)}
    case=Path(meta['case_path'])
    with (case/'project_access_review.csv').open(encoding='utf-8-sig',newline='') as f:
        access=list(csv.DictReader(f))
    w.generic('Access Evidence',access,'Recorded project/container lookup results. HTTP 404 does not establish its historical cause.')
    w.generic('Other Containers',report['other_container_rows'],'Nonproject or unverified containers; kept separate from project lists.')
    w.generic('Review Issues',report['issues'],'Issues detected from saved evidence. Blank table means no listed analysis issues.',fields=None)
    w.raw_snapshot(snapshot,summary['snapshot_data_rows'],meta['snapshot_sha256'])
    w.write_overflow()
    ranges=w.ranges; long_count=len(w.overflow)
    print('Finalizing Excel file...',flush=True)
    w.close()
    return ranges,long_count


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--snapshot',default='snowflake_snapshot.csv')
    p.add_argument('--case')
    p.add_argument('--output')
    args=p.parse_args()
    import xlsxwriter
    snapshot=Path(args.snapshot).resolve()
    print('Validating saved evidence and calculating task effort...',flush=True)
    report=analysis.analyze(snapshot,args.case)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
    output=Path(args.output).resolve() if args.output else snapshot.parent/'output'/'holistic_workbook'/stamp
    output.mkdir(parents=True,exist_ok=False)
    analysis.write_outputs(report,output/'supporting_calculations')
    temporary=output/'Wrike_Project_Access_and_Effort_BUILDING.xlsx'
    target=output/'Wrike_Project_Access_and_Effort_2026-09-30.xlsx'
    try:
        # XML may be several times the CSV size. Reserve working space for streaming output.
        if shutil.disk_usage(output).free < max(2*1024**3,snapshot.stat().st_size*12):
            raise ValueError('Insufficient disk space; at least 2 GB and 12x CSV size required')
        ranges,long_count=write_report(report,snapshot,temporary)
        with zipfile.ZipFile(temporary) as z:
            bad=z.testzip()
            if bad:raise ValueError('Workbook ZIP checksum error: '+bad)
            if 'xl/workbook.xml' not in z.namelist():raise ValueError('Missing workbook content')
        temporary.rename(target)
        receipt={'status':'WORKBOOK_CREATED_REVIEW_REQUIRED','workbook':str(target),
            'workbook_sha256':file_sha(target),'bytes':target.stat().st_size,'sheet_counts':ranges,
            'oversized_cells_preserved_in_chunks':long_count,'source':report['metadata'],
            'summary':report['summary'],'builder_sha256':file_sha(Path(__file__)),
            'xlsxwriter_version':xlsxwriter.__version__,
            'remaining_review':'Open in Excel and review summary, missing projects and supporting rows before sharing.'}
        with (output/'workbook_receipt.json').open('x',encoding='utf-8') as f:
            json.dump(receipt,f,indent=2,default=analysis.json_default)
        print('\nWORKBOOK CREATED — review required')
        for name in ['snapshot_data_rows','unique_task_count','baseline_accessible_project_count',
                     'baseline_missing_project_count','api_only_project_count','global_effort_hours','partition_residual_minutes']:
            print(name+':',report['summary'][name])
        print('EFFORT RECONCILIATION (hours):')
        for metric in report['reconciliation_rows']:
            amount=metric['effort_hours']
            print(metric['metric_id']+':', 'UNAVAILABLE' if amount is None else format(amount,',.2f'))
        print('TASK ISSUES:', report['summary']['task_issue_counts'])
        print('IDENTITY ISSUES:', report['summary']['mapping_counts'].get('ambiguous_identity_rows',0))
        print('TYPE CONFLICTS:', report['summary']['snapshot_current_type_conflict_count'])
        print('Oversized cells preserved separately:',long_count)
        print('EXCEL FILE:',target)
        print('RECEIPT:',output/'workbook_receipt.json')
    except Exception:
        print('Build did not finish. Keep the original CSV and access capture unchanged.')
        print('Partial output:',output)
        raise


if __name__=='__main__':
    try:main()
    except (ValueError,OSError,KeyError,csv.Error,ImportError) as e:
        raise SystemExit('WORKBOOK STOPPED: '+str(e))
