Wrike snapshot workbook builder — September 30, 2026

Keep these two Python files together in ~/Desktop/wrike-local-baseline:
  build_wrike_workbook.py
  wrike_report_analysis.py

Uses Python 3.9+ and the already installed XlsxWriter package. No installation,
API calls, tokens, Snowflake writes or extraction-script execution.

From that directory run:
python3 build_wrike_workbook.py --snapshot snowflake_snapshot.csv --case output/project_access_today/20260930T161721_018375Z

The script checks the source CSV hash and saved access evidence, calculates
planned effort and creates a new directory under output/holistic_workbook.
It never replaces the input CSV or the access-capture files.

The workbook includes the complete frozen snapshot, accessible projects,
missing projects, current access evidence, task-level effort, project/task
links and a reconciliation summary. API-only projects have blank effort
marked NOT_IN_SNAPSHOT. Invalid/conflicting effort remains unavailable.

Effort comes from the frozen Snowflake snapshot. Project retrieval does not
prove that Akash can retrieve every task. Matching partition totals are an
accounting check, not independent proof of extraction completeness.

Project totals may overlap. The summary separately shows accessible and missing
task unions, their overlap and tasks outside both unions. Task Effort points
back to source Excel rows. Project Task Links support the project totals.

All raw columns/rows are included. Known effort fields are numeric when Excel
can represent them with its normal precision. Other source text is preserved.
If a value exceeds Excel's cell text limit, the snapshot cell contains an
explicit reference and its full text is preserved in ordered chunks on the
Long Cell Values tab. The original CSV is unchanged.

The builder needs at least 2 GB of free disk space and reserves at least
12 times the source CSV size. It prints progress every 25,000 snapshot rows.
Do not close Terminal while it runs. The final filename is printed only after
the workbook has been finalized and its ZIP checksums have been verified.

Validation before distribution:
1. Share the final terminal reconciliation and issue counts for review.
2. Open the workbook in Microsoft Excel, allow calculation and confirm it opens
   without a repair warning. Review Reconciliation and Missing Projects.
3. Follow one project through Project Task Links and Task Effort to its raw
   snapshot rows. Check any flagged unknowns or project-type conflicts.

The calculation code was tested with synthetic duplicate/shared tasks,
API-only projects, null/conflicting effort, identity errors and tampered
evidence. The workbook was checked with synthetic data, formula recalculation
and rendered previews. Actual office data has not been supplied to ChatGPT;
the local run and your review are still required.
